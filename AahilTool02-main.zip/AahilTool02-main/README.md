
$apt update
$apt upgrade
$apt install python2
$apt install git
$pip2 install mechanize
$pip2 install requests
$git clone https://github.com/TheAahil/AahilTool02
$cd AahilTool02
$python2 Aahil.py

CODER NOT RESPONSIBLE FOR ANY MISS USE 🚫

